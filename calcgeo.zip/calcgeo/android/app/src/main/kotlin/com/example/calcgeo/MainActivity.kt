package com.example.calcgeo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
